#!/bin/bash
echo "Bulbizarre fonce sur l'adversaire avec CHARGE !"
