#!/bin/bash
echo "Bulbizarre utilise POISON sur son adversaire !"
