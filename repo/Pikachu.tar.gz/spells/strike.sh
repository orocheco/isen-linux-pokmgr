#!/bin/bash
echo "Pikachu fonce sur l'adversaire avec STRIKE !"
