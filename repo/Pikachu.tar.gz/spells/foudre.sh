#!/bin/bash
echo "Pikachu utilise FOUDRE sur son adversaire !"
