#!/bin/bash
echo "Pikachu fonce sur l'adversaire en ignorant les obstacles !"
